package com.api.maisAgua;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaisAguaApplicationTests {

	@Test
	void contextLoads() {
	}

}
